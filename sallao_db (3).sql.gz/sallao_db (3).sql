-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2024 at 04:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sallao_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_on`
--

CREATE TABLE `add_on` (
  `add_on_id` int(11) NOT NULL,
  `product_id` int(15) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_on`
--

INSERT INTO `add_on` (`add_on_id`, `product_id`, `name`, `price`) VALUES
(10, 17, 'sda', 123),
(11, 17, 'pork floss', 15),
(12, 17, 'Bonito Flakes', 15),
(13, 17, 'Mayo', 10),
(14, 27, 'Sinkers', 15),
(16, 27, 'pork floss', 123),
(17, 27, 'Bonito Flakes', 23);

-- --------------------------------------------------------

--
-- Table structure for table `option`
--

CREATE TABLE `option` (
  `option_id` int(15) NOT NULL,
  `product_id` int(15) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `option`
--

INSERT INTO `option` (`option_id`, `product_id`, `name`, `price`) VALUES
(1, 27, 'Barkada', 50),
(3, 17, 'barkada', 50),
(5, 29, 'asdasd', 213);

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `order_id` int(15) NOT NULL,
  `product_id` int(15) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `status` varchar(15) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `price` int(15) NOT NULL,
  `quantity` int(15) NOT NULL,
  `variation` varchar(255) NOT NULL,
  `order_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_price` int(15) NOT NULL,
  `total` int(15) NOT NULL,
  `payment_option` varchar(255) NOT NULL,
  `delivered_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `order_number` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`order_id`, `product_id`, `user_id`, `product_name`, `status`, `image_file`, `price`, `quantity`, `variation`, `order_time`, `total_price`, `total`, `payment_option`, `delivered_date`, `order_number`) VALUES
(55, 27, 16, 'Ramune', 'placed', '667aa38f1ea94.png', 15, 5, 'Lemonade, , Sinkers', '2024-06-26 04:28:14', 75, 100, 'Cash on Delivery', '2024-06-26 07:39:01', 8974330),
(56, 27, 16, 'Ramune', 'placed', '667aa38f1ea94.png', 65, 2, 'Lemonade, Barkada, Sinkers', '2024-06-26 04:28:14', 130, 100, 'Cash on Delivery', '2024-06-26 07:40:07', 8974330),
(57, 27, 16, 'Ramune', 'placed', '667aa38f1ea94.png', 173, 2, 'Lemonade, Barkada, pork floss', '2024-06-26 04:28:14', 346, 100, 'Cash on Delivery', '2024-06-26 09:11:51', 8974330),
(58, 17, 16, 'Takoyaki', 'placed', '667aa3b474826.png', 173, 3, 'cheese bomb, barkada, sda', '2024-06-26 04:28:14', 519, 100, 'Cash on Delivery', '2024-06-26 10:24:37', 8974330),
(59, 17, 16, 'Takoyaki', 'placed', '667aa3b474826.png', 60, 2, 'cheese bomb, barkada, Mayo', '2024-06-26 04:28:14', 120, 100, 'Cash on Delivery', '2024-06-26 10:27:55', 8974330);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(50) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `image_file` varchar(100) NOT NULL,
  `price` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `image_file`, `price`) VALUES
(17, 'Takoyaki', '667aa3b474826.png', 120),
(27, 'Ramune', '667aa38f1ea94.png', 59);

-- --------------------------------------------------------

--
-- Table structure for table `product_variants`
--

CREATE TABLE `product_variants` (
  `id` int(50) NOT NULL,
  `varient_name` varchar(50) NOT NULL,
  `varient_image` varchar(50) NOT NULL,
  `varient_price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirm` varchar(100) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `blockLot` varchar(100) NOT NULL,
  `subdivision` varchar(255) NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `image_file` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `is_admin`, `fname`, `lname`, `email`, `uname`, `password`, `confirm`, `sex`, `phone`, `blockLot`, `subdivision`, `barangay`, `city`, `province`, `zip`, `image_file`) VALUES
(1, 0, 'asd', 'asd', 'asd@gmail.com', 'asd', '123', '123', '', '', '', '', '', '', '', '', ''),
(3, 1, 'jm', 'Sallao', 'sallaojm@gmail.com', 'Sallao', '1234', '1234', '', '', '', '', '', '', '', '', ''),
(4, 0, 'jm', 'Sallao', 'sallaojm@gmail.co', 'Sallao', 'dsa', 'asd', '', '', '', '', '', '', '', '', ''),
(8, 1, 'sa', 'sa', 'sa@gmal.com', 'sasa', 'sasa', 'sasa', 'Male', '09', 'calibuyo', 'casa', 'amaya', 'tanza', 'cavite', '4081', '667592dfde465.jpg'),
(10, 0, 'John VIctor', 'Silva', 'asd@gmail.com', 'Jambik', '$2y$10$x0R3Htf8SdaoKuL0YBArWeN8ZzCClUAgFwvn4n6Cj0a/STVr5CFwS', '123', '', '', '', '', '', '', '', '', ''),
(16, 0, 'jm', 'jm', 'jm@gmail.com', 'jm', '$2y$10$VuXRmP2mzy42xCD.WC3Qh.qYbKrfpkS/EXuKVFTZ7VBrIkyYBVH1y', 'jm', '', '', '', '', '', '', '', '', '6677e818a5d67.jpg'),
(17, 0, 'cs', 'cs', 'cs.@ca', 'cs', '$2y$10$Qzq5UcjGekfS/RU9eob9QOGRPyVdWGkI4.IQSMRVTbow7X8qYxw6S', 'cs', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `variants`
--

CREATE TABLE `variants` (
  `variant_id` int(11) NOT NULL,
  `product_id` int(15) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image_file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `variants`
--

INSERT INTO `variants` (`variant_id`, `product_id`, `name`, `image_file`) VALUES
(16, 17, 'octobits', '667a82ef317ec.png'),
(28, 27, 'Lemonade', '667aa201e70a4.png'),
(29, 17, 'cheese bomb', '667aa414210ae.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_on`
--
ALTER TABLE `add_on`
  ADD PRIMARY KEY (`add_on_id`);

--
-- Indexes for table `option`
--
ALTER TABLE `option`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `variants`
--
ALTER TABLE `variants`
  ADD PRIMARY KEY (`variant_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_on`
--
ALTER TABLE `add_on`
  MODIFY `add_on_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `option`
--
ALTER TABLE `option`
  MODIFY `option_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `order_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `variants`
--
ALTER TABLE `variants`
  MODIFY `variant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
